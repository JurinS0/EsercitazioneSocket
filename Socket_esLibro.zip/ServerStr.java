import java.io.*;
import java.net.*;
import java.util.*;

public class ServerStr {
    ServerSocket server = null;
    Socket client = null;
    String stringaRicevuta = null; 
    String stringaModificata = null;
    BufferedReader inDalClient;
    DataOutputStream outVersoClient;

    // Metodo per gestire la connessione dei client
    public Socket attendi() {
        try {
            System.out.println("1 SERVER partito in esecuzione ...");
            // Creo un server sulla porta 6789
            server = new ServerSocket(6789);
            // Rimane in attesa di un client
            client = server.accept();

            // Chiudo il ServerSocket per inibire altri client
            server.close();

            // Associo due oggetti al socket del client per effettuare la scrittura e la lettura
            inDalClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
            outVersoClient = new DataOutputStream(client.getOutputStream());
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Errore durante l'istanza del server !");
            System.exit(1); // Termina il programma in caso di errore
        }
        return client;
    }
}
