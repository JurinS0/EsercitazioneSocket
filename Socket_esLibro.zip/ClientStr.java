import java.io.*;
import java.net.*;

public class ClientStr {
    Socket miosocket = null;
    BufferedReader inDalServer;
    DataOutputStream outVersoServer;
    BufferedReader tastiera = new BufferedReader(new InputStreamReader(System.in));
    String stringaUtente;
    String stringaRicevutaDalServer;

    // Metodo per stabilire la connessione con il server
    public void connetti() {
        try {
            System.out.println("CLIENT partito in esecuzione ...");
            // Indirizzo IP del server (in questo caso è localhost)
            String ipServer = "localhost";
            // Porta a cui il server è in ascolto
            int portaServer = 6789;
            // Connessione al server
            miosocket = new Socket(ipServer, portaServer);
            // Inizializzazione dei flussi di input/output per comunicare con il server
            inDalServer = new BufferedReader(new InputStreamReader(miosocket.getInputStream()));
            outVersoServer = new DataOutputStream(miosocket.getOutputStream());
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.out.println("Errore durante la connessione al server!");
            System.exit(1);
        }
    }

    // Metodo per la comunicazione con il server
    public void comunica() {
        try {
            System.out.println("CLIENT: inserisci la stringa da trasmettere al server:");
            stringaUtente = tastiera.readLine();
            // Invio la stringa al server
            outVersoServer.writeBytes(stringaUtente + '\n');
            // Leggo la risposta dal server
            stringaRicevutaDalServer = inDalServer.readLine();
            System.out.println("Risposta dal server: " + stringaRicevutaDalServer);
            // Chiudo la connessione
            System.out.println("CLIENT: connessione chiusa");
            miosocket.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.out.println("Errore durante la comunicazione con il server!");
            System.exit(1);
        }
    }
}
