public class Main {
    public static void main(String args[]) {
        ServerStr servente = new ServerStr();
        servente.attendi();
        servente.comunica();

        ClientStr cliente = new ClientStr();
        cliente.connetti();
        cliente.comunica();
    }
}
